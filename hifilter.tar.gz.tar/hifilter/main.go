package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/mucahitkurtlar/hifilter/internal/model"
	"github.com/spf13/viper"
	"github.com/xuri/excelize/v2"
)

func main() {
	viper.SetConfigFile("config.yaml")
	viper.ReadInConfig()

	f := excelize.NewFile()
	defer func() {
		if err := f.Close(); err != nil {
			log.Printf("error closing file: %v", err)
		}
	}()

	setSheetHeaders(f, "Sheet1")

	if err := f.SaveAs("Filters.xlsx"); err != nil {
		log.Printf("error saving file: %v", err)
	}

	apiBaseUrl := viper.GetString("apiBaseUrl")
	brandPath := viper.GetString("brandPath")
	productPath := viper.GetString("productPath")
	brandEndpoint := fmt.Sprintf("%s%s", apiBaseUrl, brandPath)
	productEndpoint := fmt.Sprintf("%s%s", apiBaseUrl, productPath)

	brands := []model.Brand{}
	brands = make([]model.Brand, 0)

	brandResponse, err := getBrandPage(brandEndpoint, 1)
	if err != nil {
		log.Printf("error getting brand page: %v", err)
	}

	brands = append(brands, brandResponse.Brands...)

	pageCount := brandResponse.Paging.LastPage

	for page := 2; page <= pageCount; page++ {
		brandResponse, err = getBrandPage(brandEndpoint, page)
		if err != nil {
			panic(err)
		}

		brands = append(brands, brandResponse.Brands...)

		time.Sleep(time.Duration(80 * time.Millisecond))
	}

	log.Printf("Found %d brands\n", len(brands))

	row := 2
	for _, brand := range brands {
		referenceEndpoint := fmt.Sprintf("%s%s/%s/reference", apiBaseUrl, brandPath, brand.Id)

		pageCount := 1

		for page := 1; page <= pageCount; page++ {
			referenceResponse, err := getBrandReferences(referenceEndpoint, 1)
			if err != nil {
				panic(err)
			}

			pageCount = referenceResponse.Paging.LastPage

			time.Sleep(time.Duration(100 * time.Millisecond))

			for _, product := range referenceResponse.Brands {
				productResponse, err := getProduct(productEndpoint, product.Id)
				if err != nil {
					panic(err)
				}

				for _, filter := range productResponse.Products {
					f.SetCellValue("Sheet1", fmt.Sprintf("A%d", row), filter.Reference)
					f.SetCellValue("Sheet1", fmt.Sprintf("B%d", row), productResponse.Reference)
					f.SetCellValue("Sheet1", fmt.Sprintf("C%d", row), productResponse.Brand.Name)
					f.SetCellValue("Sheet1", fmt.Sprintf("D%d", row), filter.Family)
					f.SetCellValue("Sheet1", fmt.Sprintf("E%d", row), filter.Attributes)
					f.SetCellValue("Sheet1", fmt.Sprintf("F%d", row), filter.Gencode)
				}

				row++

				time.Sleep(time.Duration(60 * time.Millisecond))
			}

			if err := f.SaveAs("Filters.xlsx"); err != nil {
				log.Printf("error saving file: %v", err)
			}

			log.Printf("%d filters added\n", row-2)
		}
	}

	if err := f.SaveAs("Filters.xlsx"); err != nil {
		log.Printf("error saving file: %v", err)
	}
}

func getBrandPage(brandEndpoint string, page int) (model.BrandResponse, error) {
	resp, err := http.Get(fmt.Sprintf("%s?p=%d", brandEndpoint, page))
	if err != nil {
		return model.BrandResponse{}, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return model.BrandResponse{}, err
	}

	var brandResponse model.BrandResponse
	err = json.Unmarshal(body, &brandResponse)
	if err != nil {
		return model.BrandResponse{}, err
	}

	return brandResponse, nil
}

func getBrandReferences(brandEndpoint string, page int) (model.BrandResponse, error) {
	resp, err := http.Get(fmt.Sprintf("%s?p=%d", brandEndpoint, page))
	if err != nil {
		return model.BrandResponse{}, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return model.BrandResponse{}, err
	}

	var brandResponse model.BrandResponse
	err = json.Unmarshal(body, &brandResponse)
	if err != nil {
		return model.BrandResponse{}, err
	}

	return brandResponse, nil
}

func getProduct(productEndpoint, productId string) (model.ProductResponse, error) {
	resp, err := http.Get(fmt.Sprintf("%s/%s", productEndpoint, productId))
	if err != nil {
		return model.ProductResponse{}, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return model.ProductResponse{}, err
	}

	var productResponse model.ProductResponse
	err = json.Unmarshal(body, &productResponse)
	if err != nil {
		return model.ProductResponse{}, err
	}

	return productResponse, nil
}

func setSheetHeaders(f *excelize.File, sheetName string) {
	f.SetCellValue(sheetName, "A1", "NAME")
	f.SetCellValue(sheetName, "B1", "REFERENCE")
	f.SetCellValue(sheetName, "C1", "BRAND")
	f.SetCellValue(sheetName, "D1", "FAMILY")
	f.SetCellValue(sheetName, "E1", "ATTRIBUTES")
	f.SetCellValue(sheetName, "F1", "GENCODE")

	f.SetColWidth(sheetName, "A", "C", 25)
	f.SetColWidth(sheetName, "E", "E", 35)
	f.SetColWidth(sheetName, "F", "F", 25)
}
