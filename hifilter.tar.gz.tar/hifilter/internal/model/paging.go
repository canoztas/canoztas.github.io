package model

type Paging struct {
	CurrenPage   int `json:"currentPage"`
	PageSize     int `json:"pageSize"`
	Count        int `json:"count"`
	TotalFetched int `json:"totalFetched"`
	Total        int `json:"totalPages"`
	LastPage     int `json:"lastPage"`
	PrevPage     int `json:"prevPage"`
	NextPage     int `json:"nextPage"`
}
