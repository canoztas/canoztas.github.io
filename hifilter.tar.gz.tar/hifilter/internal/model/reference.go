package model

type Reference struct {
	Id        string `json:"id"`
	Reference string `json:"reference"`
}
