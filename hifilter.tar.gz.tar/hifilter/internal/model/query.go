package model

type Query struct {
	Id   string `json:"id"`
	Page int    `json:"page"`
}
