package model

type ReferenceResponse struct {
	Id      string   `json:"id"`
	Query   Query    `json:"query"`
	Paging  Paging   `json:"paging"`
	Results []Result `json:"results"`
}
