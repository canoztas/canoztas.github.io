package model

type BrandResponse struct {
	Id     string  `json:"id"`
	Query  Query   `json:"query"`
	Paging Paging  `json:"paging"`
	Brands []Brand `json:"results"`
}
