package model

type ProductResponse struct {
	Id        string    `json:"id"`
	Reference string    `json:"reference"`
	Brand     Brand     `json:"brand"`
	Products  []Product `json:"products"`
}
