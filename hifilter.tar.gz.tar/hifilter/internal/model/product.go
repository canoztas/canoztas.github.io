package model

type Product struct {
	Id                string      `json:"id"`
	Number            string      `json:"number"`
	Reference         string      `json:"reference"`
	RecordId          int         `json:"record_id"`
	Family            string      `json:"family"`
	Lifecycle         string      `json:"lifecycle"`
	Designation       string      `json:"designation"`
	Photos            []Photo     `json:"photos"`
	Drawings          []Drawing   `json:"drawings"`
	CustomerReference string      `json:"customerReference"`
	Volume            int         `json:"volume"`
	Weight            int         `json:"weight"`
	OriginCountry     string      `json:"originCountry"`
	CommodityCode     string      `json:"commodityCode"`
	FilterCode4       string      `json:"filterCode4"`
	Gencode           string      `json:"gencode"`
	Attributes        []Attribute `json:"attributes"`
	IsPersonalized    bool        `json:"isPersonalized"`
	IsNeutral         bool        `json:"isNeutral"`
}

type Photo struct {
	Id             string `json:"id"`
	Product        string `json:"product"`
	BroadcastType  string `json:"broadcastType"`
	BroadcastOrder int    `json:"broadcastOrder"`
	Comment        string `json:"comment"`
}

type Drawing struct {
	Id             string `json:"id"`
	Product        string `json:"product"`
	BroadcastType  string `json:"broadcastType"`
	BroadcastOrder int    `json:"broadcastOrder"`
	Comment        string `json:"comment"`
}

type Attribute struct {
	Code         string  `json:"code"`
	Type         string  `json:"type"`
	Unit         string  `json:"unit"`
	DecimalValue float32 `json:"decimalValue"`
	StringValue  string  `json:"stringValue"`
	IsPublic     bool    `json:"isPublic"`
	Internal     bool    `json:"internal"`
}
